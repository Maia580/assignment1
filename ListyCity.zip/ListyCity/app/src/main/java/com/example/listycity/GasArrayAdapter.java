package com.example.listycity;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

public class GasArrayAdapter extends ArrayAdapter<Station> {

    public GasArrayAdapter(MainActivity context, ArrayList<Station> dataList) {
        super();
    }

    @SuppressLint("NotConstructor")
    public void GasArrayAdapter(Context context, ArrayList<Station> cities) {
        super(context, 0, cities);
    }

    public GasArrayAdapter(@NonNull Context context, ArrayList<Station> resource) {
        super(context, resource);
    }

    public GasArrayAdapter(@NonNull Context context, int resource, int textViewResourceId) {
        super(context, resource, textViewResourceId);
    }

    public GasArrayAdapter(@NonNull Context context, int resource, @NonNull station[] objects) {
        super(context, resource, objects);
    }

    public GasArrayAdapter(@NonNull Context context, int resource, int textViewResourceId, @NonNull station[] objects) {
        super(context, resource, textViewResourceId, objects);
    }

    public GasArrayAdapter(@NonNull Context context, int resource, @NonNull List<station> objects) {
        super(context, resource, objects);
    }

    public GasArrayAdapter(@NonNull Context context, int resource, int textViewResourceId, @NonNull List<station> objects) {
        super(context, resource, textViewResourceId, objects);
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View view;
        if (convertView == null) {
            view = LayoutInflater.from(super.getContext()).inflate(R.layout.content, parent, false);
        } else {
            view = convertView;
        }
        Station station = super.getItem(position);
        TextView stationName = view.findViewById(R.id.name_text);
        TextView dateName = view.findViewById(R.id.date_text);
        EditText amountName = view.findViewById(R.id.amount_text);


        stationName.setText(station.getName());
        dateName.setText(station.getDate());
        //amountName.setText(station.getAmount())
        return view;
    }
}

